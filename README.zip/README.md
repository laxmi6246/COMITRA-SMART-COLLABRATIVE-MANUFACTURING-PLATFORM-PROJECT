# CoMitra — Smart Collaborative Manufacturing Platform

> **Tagline:** One Order. Multiple Manufacturers. One Success.  
> **Project Type:** Full-Stack B2B Industrial Manufacturing Collaboration Platform  
> **Suitability:** College Final Review, Industrial Live Demonstration, and Scalable Enterprise Deployment.

---

## 1. Executive Summary & Problem Statement

### The Problem
Medium and large manufacturing enterprises routinely receive bulk supply contracts (e.g., 10,000+ precision metal assemblies, automotive brackets, or specialized machined parts) that exceed their immediate single-plant capacity, machine availability, or tight delivery deadlines. Historically, companies were forced to:
1. **Outright reject lucrative contracts**, losing customer relationships and revenue.
2. **Subcontract through opaque informal channels**, suffering from unverified quality, missed delivery milestones, and payment disputes.
3. At the same time, regional partner manufacturers often have **idle machines and unused capacity** that remain unmonetized due to lack of a unified coordination network.

### The Solution: CoMitra
**CoMitra** is a centralized, digital collaborative manufacturing platform that enables manufacturing businesses to accept high-volume orders together. The order owner publishes the contract, discovers compatible verified manufacturing partners through an explainable rule-based matching engine, allocates production quotas, coordinates real-time milestone tracking, executes digital collaboration agreements, and manages structured milestone invoicing.

---

## 2. Live Demonstration Scenario

The application is pre-configured with realistic fictional demonstration data illustrating the complete workflow:

```mermaid
sequenceDiagram
    autonumber
    actor A as ArcelorMittal Fab (Order Owner)
    participant Platform as CoMitra Platform
    actor B as SteelTech Ltd (Partner 1)
    actor C as PrecisionForge (Partner 2)

    A->>Platform: Publishes Order for 10,000 Engine Brackets (Cap: 6,000)
    Platform->>Platform: Smart Matching Engine evaluates 6 scoring factors
    Platform->>A: Recommends SteelTech (88% Match) & PrecisionForge (76% Match)
    A->>B: Sends Invitation for 2,500 units allocation
    A->>C: Sends Invitation for 1,500 units allocation
    B->>Platform: Accepts invitation (Capacity locked)
    C->>Platform: Accepts invitation (Capacity locked)
    Platform->>A: Order moved to IN_PRODUCTION (10,000/10,000 allocated)
    Platform->>Platform: Generates Multi-Party Collaboration Agreement
    A->>Platform: Signs digital agreement
    B->>Platform: Signs digital agreement
    C->>Platform: Signs digital agreement
    B->>Platform: Logs Batch 1 completion (800 units machined & inspected)
    B->>A: Issues Milestone Invoice INV-2025-DEMO-001 (₹12,53,750 incl. GST)
    A->>Platform: Verifies output & records simulated payment settlement
    A->>B: Submits 5-star performance rating & review
```

### Pre-Configured Demo Accounts (Password: `demo1234`)
| Account Role | Email | Company Name | Key Responsibilities |
| :--- | :--- | :--- | :--- |
| **Order Owner** | `arcelormittal@comitra.demo` | ArcelorMittal Fabrications | Publishes bulk orders, discovers partners, allocates quotas, signs agreements, approves payables. |
| **Partner 1** | `steeltech@comitra.demo` | SteelTech Pvt Ltd | Accepts allocations, reports machining milestones, issues invoices, tracks capacity. |
| **Partner 2** | `precisionforge@comitra.demo` | PrecisionForge Components | Specializes in forging/casting, fulfills allocated batches, signs contracts. |
| **Platform Admin** | `admin@comitra.demo` | Platform Administrator | Audits platform activity, verifies new manufacturing plants, monitors compliance. |

---

## 3. System Architecture & Technology Stack

```
┌────────────────────────────────────────────────────────┐
│                   CoMitra Frontend                     │
│  Next.js 14 (App Router) + React 19 + TypeScript       │
│  Tailwind CSS + shadcn/ui + Radix UI + Lucide Icons    │
│  Recharts (Data Visualization & Production Analytics)  │
└───────────────────────────▲────────────────────────────┘
                            │ REST / Route Handlers
┌───────────────────────────▼────────────────────────────┐
│                    CoMitra Backend                     │
│  Next.js Route Handlers + Zod Request Validation       │
│  Auth.js v5 (Secure Credentials & JWT Session Guard)   │
│  Rule-Based Transparent Partner Matching Engine        │
│  Multi-Party Workflow & Audit Logging Subsystem        │
└───────────────────────────▲────────────────────────────┘
                            │ Prisma ORM
┌───────────────────────────▼────────────────────────────┐
│                    Database Layer                      │
│  PostgreSQL / Supabase / Neon                          │
│  20+ Normalized Models with Referential Integrity      │
│  Automated Migrations & Repeatable Seed Scripts        │
└────────────────────────────────────────────────────────┘
```

- **Frontend:** Next.js (App Router), React, TypeScript, Tailwind CSS, Radix UI primitives, Recharts.
- **Backend:** Next.js Route Handlers, Zod schema validation, server-side authorization middleware.
- **Authentication:** Auth.js v5 with session-enriched JWT callbacks (`user.role`, `user.businessId`).
- **Database:** PostgreSQL with Prisma ORM, migrations, and comprehensive seed data.
- **Testing:** Vitest unit test suites for matching engine and utilities.

---

## 4. Rule-Based Partner Matching Engine

CoMitra avoids unpredictable "black-box" AI models in favor of an **explainable, deterministic, multi-factor scoring formula** tailored to industrial compliance:

$$\text{Overall Score} = \sum_{i=1}^{6} (S_i \times W_i)$$

Where $S_i \in [0, 100]$ is the normalized factor score, and $W_i$ is the configurable factor weight:

| Factor ($i$) | Weight ($W_i$) | Evaluation Criteria | Hard Exclusion Gate |
| :--- | :---: | :--- | :--- |
| **1. Capability Match** | **35%** | Jaccard overlap between required order capabilities (e.g. CNC, Stamping, Welding) and candidate plant capabilities. | Candidates with 0% capability overlap are excluded. |
| **2. Available Capacity** | **25%** | Ratio of free capacity $(\text{Total} - \text{Committed})$ to required quota allocation. | Candidates with zero free capacity are excluded. |
| **3. Deadline Feasibility** | **20%** | Production cycle feasibility based on days remaining before delivery deadline. | Orders overdue or deadline `< 3` days trigger flags. |
| **4. Quality & Certifications** | **10%** | ISO 9001, IATF 16949, AS9100 credentials and platform verification status. | Non-verified plants receive normalized penalty. |
| **5. Location Proximity** | **5%** | Same industrial cluster or city (100 pts), same state (85 pts), domestic (70 pts). | — |
| **6. Collaboration History** | **5%** | Historical delivery success rate $(\text{Completed} / \text{Total Orders})$ and partner ratings. | Missing history defaults to neutral baseline (70 pts). |

### Match Categories
- **EXCELLENT MATCH (85% – 100%):** Strong capability overlap, ample capacity, verified certifications, local logistics.
- **GOOD MATCH (70% – 84%):** Capable partner with minor capacity or geographic variance.
- **FAIR MATCH (50% – 69%):** Partial capability match; may require supplementary tooling.
- **POOR MATCH (< 50%):** Ineligible or insufficient capacity.

---

## 5. Security & Role-Based Access Control (RBAC)

1. **Server-Side Authorization:** Every route handler and server page independently verifies session state and business ownership. Ordinary manufacturers cannot view private drafts or unassociated partner records.
2. **Platform Admin Guard:** Administrator routes (`/admin/*` and `/api/admin/*`) strictly verify `session.user.role === "ADMIN"`. Non-admin requests are redirected or denied with HTTP 403.
3. **Audit Logging:** Every critical state transition (order creation, invitation acceptance, agreement signing, payment settlement, business verification) is permanently recorded in the `AuditEvent` table with actor ID, entity reference, and metadata.

---

## 6. Project Modules & Features

1. **Landing Page & Onboarding:** Modern dark navy landing page showcasing workflow steps, benefits, demo timeline, and multi-step manufacturer onboarding wizard.
2. **Dashboard:** Live operational dashboard with order status breakdown, capacity utilization meter, active deadlines, and real-time notifications.
3. **Bulk Order Management:** Detailed specification builder (tolerances, materials, standards, delivery requirements) with quota split calculator.
4. **Partner Discovery & Matching:** Ranked partner cards with expandable transparent scoring breakdowns and instant invitation modals.
5. **Collaborations Hub:** Incoming & outgoing invitations management with capacity-checked accept/reject workflows.
6. **Production Tracking:** Per-allocation progress bars, milestone checklists, and delay/quality exception reporting.
7. **Agreements:** Formal multi-party digital co-manufacturing contracts with printable PDF export and timestamped digital signatures.
8. **Invoicing & Payments:** B2B GST tax invoices, itemized line items, and simulated payment settlement workflows.
9. **Directory & Profiles:** Searchable manufacturing marketplace filterable by sector, city, and verified status.
10. **Analytics:** Recharts data visualizations showing in-house vs partner output volume, pipeline stages, and category breakdown.
11. **Admin Workspace:** Verification queue reviewing industrial licenses and live security audit log.

---

## 7. Setup & Installation Guide

### Prerequisites
- Node.js v18+ or v20+
- PostgreSQL database (Local or managed on Supabase/Neon)

### Installation Steps

1. **Clone repository and enter project directory:**
   ```bash
   git clone <repo-url>
   cd comitra
   ```

2. **Configure environment variables:**
   Copy `.env.example` to `.env.local` and set your database connection string and NextAuth secret:
   ```env
   DATABASE_URL="postgresql://postgres:password@localhost:5432/comitra_db?schema=public"
   AUTH_SECRET="comitra-production-secure-key-32-chars-min"
   AUTH_URL="http://localhost:3000"
   NEXT_PUBLIC_APP_URL="http://localhost:3000"
   ```

3. **Install dependencies:**
   ```bash
   npm install
   ```

4. **Initialize database schema & run demo seed:**
   ```bash
   npx prisma generate
   npx prisma db push
   npm run db:seed
   ```

5. **Start development server:**
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) to view CoMitra. Use the one-click demo login buttons on the Sign In page to immediately experience the platform as an Order Owner, Partner, or Administrator.

---

## 8. License & Academic Disclaimer
Developed as a demonstration of collaborative manufacturing systems engineering. Suitable for academic assessment, project viva, and future commercial extension.
